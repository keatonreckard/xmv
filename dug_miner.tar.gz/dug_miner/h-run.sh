#!/usr/bin/env bash

. h-manifest.conf

./dug_miner $(< ./$CUSTOM_NAME.conf) --api-port=${CUSTOM_API_PORT} | tee $CUSTOM_LOG_BASENAME.log
