#!/usr/bin/env bash

. h-manifest.conf

./dug_miner $(< ./$CUSTOM_NAME.conf) 